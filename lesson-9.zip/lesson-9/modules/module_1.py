"""This is a study module for lesson-9"""


def is_string(string) -> bool:
    return isinstance(string, str)
