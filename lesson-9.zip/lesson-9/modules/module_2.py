from random import random

def print_random_numb(times: int) -> None:
    for i in range(times):
        print(random())
